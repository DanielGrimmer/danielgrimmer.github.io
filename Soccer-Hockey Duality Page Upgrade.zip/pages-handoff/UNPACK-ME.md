# Unpack at the repo root

This archive holds two things, already at their final paths:

    assets/games/ui/pages.css            ← new source, commit as-is
    _design/soccer-hockey-pages/         ← the brief, the copy, and the design

Unzip it at the root of danielgrimmer.github.io and nothing is overwritten:
`pages.css` is a new file, and `_design/` is a new folder. Then read
`_design/soccer-hockey-pages/README.md` and follow it.

Jekyll note: a top-level folder beginning with an underscore is not copied into
`_site`, so `_design/` is not published. Leave it that way — it is the brief, not
a page. If you would rather it not live in the repo at all, implement from it and
delete the folder in the same commit as the last page.

Nothing here changes the board. `board.css`, `board.js` and `assets/games/img/`
are finished and live on main; do not modify them.
